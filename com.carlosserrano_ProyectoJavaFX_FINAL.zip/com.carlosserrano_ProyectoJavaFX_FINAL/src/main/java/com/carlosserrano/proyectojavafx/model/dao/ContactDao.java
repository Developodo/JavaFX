package com.carlosserrano.proyectojavafx.model.dao;

import com.carlosserrano.proyectojavafx.controller.AppController;
import com.carlosserrano.proyectojavafx.model.Channel;
import com.carlosserrano.proyectojavafx.model.Contact;
import com.carlosserrano.proyectojavafx.utils.ConnectionUtil;
import com.carlosserrano.proyectojavafx.utils.Dialog;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ContactDao extends Contact implements Dao {

    enum queries {
        INSERT("INSERT INTO contactos (id,name,birthdate) VALUES (NULL,?,?)"),
        ALL("SELECT * FROM contactos"),
        GETCHANNELS("SELECT * FROM channel WHERE id_contact=?"),
        GETBYID("SELECT * FROM contactos WHERE id=?"),
        FINDBYID("SELECT * FROM contactos WHERE id IN "), //<-- ojo con esta, hay formas más elegantes
        FINDBYNAME("SELECT * FROM contactos WHERE name LIKE ?"),
        UPDATE("UPDATE contactos SET name = ?, birthdate = ? WHERE id = ?"),
        REMOVE("DELETE FROM contactos WHERE id=?");
        private String q;

        queries(String q) {
            this.q = q;
        }

        public String getQ() {
            return this.q;
        }
    }

    Connection con;
    private boolean persist;

    public ContactDao(int id, String nickname, List<Channel> channels, LocalDate birthDate) {
        super(id, nickname, channels, birthDate);
        con = ConnectionUtil.connect(AppController.currentConnection);
        persist = false;
    }

    public ContactDao() {
        super();
        con = ConnectionUtil.connect(AppController.currentConnection);
        persist = false;
    }

    //DAO
    public ContactDao(Contact c) {
        this(c.getId(), c.getNickname(), c.getChannels(), c.getBirthDate());
    }

    public ContactDao(int i) {
        this();
        List<Object> params = new ArrayList<>();
        params.add(i);
        try {
            ResultSet rs = ConnectionUtil.execQuery(con, queries.GETBYID.getQ(), params);

            if (rs != null) {

                while (rs.next()) {
                    Contact c = instanceBuilder(rs);
                    this.id = c.getId();
                    this.nickname = c.getNickname();
                    this.birthDate = c.getBirthDate();
                    this.channels = c.getChannels();
                }

            }
        } catch (SQLException ex) {
            Dialog.showError("ERRPR", "Error cargando el contacto", ex.toString());
        }
    }

    public void persist() {
        this.persist = true;
    }

    public void detach() {
        this.persist = false;
    }

    @Override
    public List<Channel> getChannels() {
        if (this.channels == null) {
            //lazy retrieve
            List<Channel> result = ChannelDao.getByContact(con, id);

            this.setChannels(result);
        }
        return super.getChannels();
    }

    @Override
    public void setBirthDate(LocalDate birthDate) {
        super.setBirthDate(birthDate);
        if (persist) {
            save();
        }
    }

    @Override
    public void setChannels(List<Channel> channels) {
        super.setChannels(channels);
        if (persist) {
            save();
        }
    }

    @Override
    public void setNickname(String nickname) {
        super.setNickname(nickname);
        if (persist) {
            save();
        }
    }

    @Override
    public void setId(int id) {
        /*super.setId(id); 
        if(persist){
            save();
        }*/
        //primary key cannot be changed
    }

    public void save() {
        queries q;
        List<Object> params = new ArrayList<>();
        params.add(this.getNickname());
        params.add(this.getBirthDate());

        if (this.id == -1) {
            q = queries.INSERT;
        } else {
            q = queries.UPDATE;
            params.add(this.id);
        }

        try {
            //Comienza transacción
            con.setAutoCommit(false);

            int rs = ConnectionUtil.execUpdate(con, q.getQ(), params, (q == queries.INSERT ? true : false));
            if (q == ContactDao.queries.INSERT) {
                this.id = rs;
            }
            if (channels != null) {  //si se ha modificado algo sobre channels
                //Borrando aquellos que no están ya -> coherencia
                List<Channel> oldChannels = ChannelDao.getByContact(con, id);
                for (Channel oldChannel : oldChannels) {
                    if (!channels.contains(oldChannel)) {
                        ChannelDao cd = new ChannelDao(oldChannel);
                        cd.remove();
                    }
                }
                //Actualizando o insertando los nuevos
                for (Channel newChannels : channels) {
                    ChannelDao cd = new ChannelDao(newChannels);
                    cd.setId_contact(id);  //me aseguro de la relación 
                    cd.save();
                }
            }

            //Fin de la transacción
            con.commit();
            con.setAutoCommit(true);
        } catch (SQLException ex) {
            Dialog.showError("ERROR", "Error guardando contacto", ex.toString());
        }

    }

    public void remove() {
        if (this.id != -1) {
            try {
                //Comienza transacción
                con.setAutoCommit(false);

                //Boorando aquellos que no están ya -> coherencia
                List<Channel> oldChannels = ChannelDao.getByContact(con, id);

                for (Channel oldChannel : oldChannels) {
                    ChannelDao cd = new ChannelDao(oldChannel);
                    cd.remove();
                }
                int rs = ConnectionUtil.execUpdate(con, queries.REMOVE.getQ(), this.id, false);

                //Fin de la transacción
                con.commit();
                con.setAutoCommit(true);

            } catch (SQLException ex) {
                Dialog.showError("ERROR", "Error borrando contacto", ex.toString());
            }
        }
    }

    // UTILS for CONTACT DAO
    public static Contact instanceBuilder(ResultSet rs) {
        //ojo rs.getMetaData()
        Contact c = new Contact();
        if (rs != null) {
            try {
                c.setId(rs.getInt("id"));
                c.setNickname(rs.getString("name"));
                c.setBirthDate(rs.getDate("birthdate").toLocalDate());
                //falta lazy contacts
            } catch (SQLException ex) {
                Dialog.showError("Error SQL", "SQL creando contacto", ex.toString());
            }

        }
        return c;
    }

    public static List<Contact> getAll(Connection con) {
        List<Contact> result = new ArrayList<>();
        try {
            ResultSet rs = ConnectionUtil.execQuery(con, queries.ALL.getQ(), null);
            if (rs != null) {
                while (rs.next()) {
                    Contact n = ContactDao.instanceBuilder(rs);
                    result.add(n);
                }
            }
        } catch (SQLException ex) {
            Dialog.showError("ERRPR", "Error cargando el contactos", ex.toString());
        }
        return result;
    }

    public static List<Contact> getByName(Connection con, String name) {
        List<Contact> result = new ArrayList<>();
        try {
            ResultSet rs = ConnectionUtil.execQuery(con, queries.FINDBYNAME.getQ(), name + "%");
            if (rs != null) {
                while (rs.next()) {
                    Contact n = ContactDao.instanceBuilder(rs);
                    result.add(n);
                }
            }
        } catch (SQLException ex) {
            Dialog.showError("ERRPR", "Error cargando el contactos", ex.toString());
        }
        return result;
    }

    public static List<Contact> getById(Connection con, List<Integer> ids) {
        List<Contact> result = new ArrayList<>();
        try {
            List<String> newList = new ArrayList<String>(ids.size());
            for (Integer myInt : ids) {
                newList.add(String.valueOf(myInt));
            }
            String queryTotal = queries.FINDBYID.getQ() + "(" + String.join(",", newList) + ");";

            ResultSet rs = ConnectionUtil.execQuery(con, queryTotal, null);
            if (rs != null) {
                while (rs.next()) {
                    Contact n = ContactDao.instanceBuilder(rs);
                    result.add(n);
                }
            }
        } catch (SQLException ex) {
            Dialog.showError("ERRPR", "Error cargando el contactos", ex.toString());
        }
        return result;
    }

}
