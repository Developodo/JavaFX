package com.carlosserrano.proyectojavafx.controller;

import com.carlosserrano.proyectojavafx.model.Channel;
import com.carlosserrano.proyectojavafx.model.Contact;
import com.carlosserrano.proyectojavafx.model.dao.ChannelDao;
import com.carlosserrano.proyectojavafx.model.dao.ContactDao;
import com.carlosserrano.proyectojavafx.utils.ConnectionUtil;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.ResourceBundle;
import java.util.Set;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.HBox;

public class PrimaryController extends Controllers implements Initializable {

    //OBSERVABLE <--------
    public ObservableList<Contact> contacts;
    public ObservableList<Channel> channels;

    @FXML
    private TableView<Contact> contactTable;

    @FXML
    private TableColumn<Contact, String> nameCol;
    @FXML
    private TableColumn<Contact, String> birthCol;

    @FXML
    private TableView<Channel> channelTable;

    @FXML
    private TableColumn<Channel, String> typeCol;
    @FXML
    private TableColumn<Channel, String> valueCol;

    private java.sql.Connection con;
    
    @FXML
    private TextField searchPattern;
    @FXML
    private Button deleteContact;
    @FXML
    private Button deleteChannel;
    @FXML
    private HBox menuChannel;
            

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.contacts = FXCollections.observableArrayList();

        //loading
        this.con = ConnectionUtil.connect(AppController.currentConnection);
        if (con != null) {
            List<Contact> c = ContactDao.getAll(con);
            this.contacts.addAll(c);
        }

        nameCol.setCellValueFactory(cellData -> {
            return new SimpleObjectProperty<>(cellData.getValue().getNickname());
        });
        nameCol.setCellFactory(TextFieldTableCell.forTableColumn());
        nameCol.setOnEditCommit(
                new EventHandler<TableColumn.CellEditEvent<Contact, String>>() {
            @Override
            public void handle(TableColumn.CellEditEvent<Contact, String> t) {

                Contact selected = (Contact) t.getTableView().getItems().get(
                        t.getTablePosition().getRow());
                selected.setNickname(t.getNewValue());
                ContactDao cc = new ContactDao(selected);
                cc.save();
            }
        }
        );

        birthCol.setCellValueFactory(cellData -> {
            return new SimpleObjectProperty<>(cellData.getValue().getBirthDate().toString());
        });
        birthCol.setCellFactory(TextFieldTableCell.forTableColumn());
        birthCol.setOnEditCommit((TableColumn.CellEditEvent<Contact, String> t) -> {
            Contact selected = (Contact) t.getTableView().getItems().get(
                    t.getTablePosition().getRow());
            selected.setBirthDate(LocalDate.parse(t.getNewValue()));  //habría que validar
            ContactDao cc = new ContactDao(selected);
            cc.save();
        });

        contactTable.setEditable(true);

        contactTable.getSelectionModel().cellSelectionEnabledProperty().set(true);

        contactTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> showChannels(newValue)
        );
        //Add observable
        contactTable.setItems(contacts);

        this.channels = FXCollections.observableArrayList();

        typeCol.setCellValueFactory(cellData -> {
            return new SimpleObjectProperty<>(cellData.getValue().getType());
        });
        typeCol.setCellFactory(TextFieldTableCell.forTableColumn());
        typeCol.setOnEditCommit((TableColumn.CellEditEvent<Channel, String> t) -> {
            Channel selected = (Channel) t.getTableView().getItems().get(
                    t.getTablePosition().getRow());
            selected.setType(t.getNewValue());
            ChannelDao cc = new ChannelDao(selected);
            cc.save();
        });
        valueCol.setCellValueFactory(cellData -> {
            return new SimpleObjectProperty<>(cellData.getValue().getValue());
        });
        valueCol.setCellFactory(TextFieldTableCell.forTableColumn());
        valueCol.setOnEditCommit((TableColumn.CellEditEvent<Channel, String> t) -> {
            Channel selected = (Channel) t.getTableView().getItems().get(
                    t.getTablePosition().getRow());
            selected.setValue(t.getNewValue());  //habría que validar
            ChannelDao cc = new ChannelDao(selected);
            cc.save();
        });
        
        channelTable.setEditable(true);

        channelTable.getSelectionModel().cellSelectionEnabledProperty().set(true);
        
        channelTable.setItems(channels);
        showChannels(null);
        
        searchPattern.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent t) {
                search();  //<--searchPattern.getText()
            }

        });

    }

    private void showChannels(Contact c) {
        channels.clear();
        if (c != null) {
            List<Channel> lc = ChannelDao.getByContact(con, c.getId());
            channels.addAll(lc);
            menuChannel.setDisable(false);
            deleteContact.setDisable(false);
        }else{
            menuChannel.setDisable(true);
            deleteContact.setDisable(true);
        }
    }

    @Override
    void onLoad() {
        this.app.controller.title("CRUD - JAVAFX");
        this.app.controller.enableCon();
    }

    @FXML
    public void addContact() {
        Contact nuevo=new Contact();
        ContactDao nuevoDao=new ContactDao(nuevo);
        nuevoDao.save();
        nuevo.setId(nuevoDao.getId());
        contacts.add(nuevo);
    }

    @FXML
    public void removeContact() {
        Contact selected = contactTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            contacts.remove(selected);
            ContactDao cc = new ContactDao(selected);
            cc.remove();
        }
    }

    @FXML
    public void addChannel() {
        Contact selected = contactTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Channel nc = new Channel();
            nc.setType("email");
            nc.setId_contact(selected.getId());
            ChannelDao ncdao=new ChannelDao(nc);
            ncdao.save();
            nc.setId(ncdao.getId());
            channels.add(nc);
        }
    }

    @FXML
    public void removeChannel() {
        Contact selected = contactTable.getSelectionModel().getSelectedItem();
        if (selected != null) {
            Channel selectedC = channelTable.getSelectionModel().getSelectedItem();
            if (selectedC != null) {
                channels.remove(selectedC);
                (new ChannelDao(selectedC)).remove();
            }
        }
    }
    
    @FXML
    public void search(){
        String pattern=searchPattern.getText();
        pattern=pattern.trim();
        contacts.clear();
        List<Contact> newC;
        if(pattern.equals("")){
            newC=ContactDao.getAll(con);
        }else{
            newC=ContactDao.getByName(con, pattern);
        }
        
        //Extra funcion -> buscar también por contacto
        
        List<Contact> newC2=new ArrayList<>();
        if(!pattern.equals("")){
            List<Channel> lc=ChannelDao.getByValue(con, pattern);
            Set<Integer> listId=new HashSet<>();
            lc.stream().forEach(c->{
                listId.add(c.getId_contact());
            });
            if(listId.size()>0){
                newC2=ContactDao.getById(con, new ArrayList(listId));
            }
        }
        contacts.addAll(newC);
        for(Contact c:newC2){
            if(!contacts.contains(c)){
                contacts.add(c);
            }
        }
    }

}
