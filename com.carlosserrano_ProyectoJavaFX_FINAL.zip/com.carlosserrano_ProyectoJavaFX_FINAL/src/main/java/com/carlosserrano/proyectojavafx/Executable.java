package com.carlosserrano.proyectojavafx;

public class Executable {
    public static void main(String[] args) {
        App.main(args);
    }
    
}
