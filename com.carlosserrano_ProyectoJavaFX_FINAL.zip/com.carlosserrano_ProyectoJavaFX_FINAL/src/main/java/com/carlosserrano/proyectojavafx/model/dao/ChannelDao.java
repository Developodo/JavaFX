package com.carlosserrano.proyectojavafx.model.dao;

import com.carlosserrano.proyectojavafx.controller.AppController;
import com.carlosserrano.proyectojavafx.model.Channel;
import com.carlosserrano.proyectojavafx.utils.ConnectionUtil;
import com.carlosserrano.proyectojavafx.utils.Dialog;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ChannelDao extends Channel {

    enum queries {
        INSERT("INSERT INTO channel (id,type,value,id_contact) VALUES (NULL,?,?,?)"),
        ALL("SELECT * FROM channel"),
        GETBYID("SELECT * FROM channel WHERE id=?"),
        FINDBYCONTACT("SELECT * FROM channel WHERE id_contact =?"),
        FINDBYVALUE("SELECT * FROM channel WHERE value LIKE ?"),
        UPDATE("UPDATE channel SET type = ?, value = ? WHERE id = ?"),
        REMOVE("DELETE FROM channel WHERE id=?");
        private String q;

        queries(String q) {
            this.q = q;
        }

        public String getQ() {
            return this.q;
        }
    }

    Connection con;
    private boolean persist;

    public ChannelDao(int id, String type, String value, int id_contact) {
        super(id, type, value, id_contact);
        con = ConnectionUtil.connect(AppController.currentConnection);
        persist = false;
    }

    public ChannelDao() {
        super();
        con = ConnectionUtil.connect(AppController.currentConnection);
        persist = false;
    }

    public ChannelDao(Channel c) {
        this(c.getId(), c.getType(), c.getValue(), c.getId_contact());
    }

    public ChannelDao(int i) {
        this();
        try {
            ResultSet rs = ConnectionUtil.execQuery(con, ContactDao.queries.GETBYID.getQ(), i);

            if (rs != null) {

                while (rs.next()) {
                    Channel c = instanceBuilder(rs);
                    this.id = c.getId();
                    this.type = c.getType();
                    this.value = c.getValue();
                    this.id_contact = c.getId_contact();
                }

            }
        } catch (SQLException ex) {
            Dialog.showError("ERRPR", "Error cargando el canal", ex.toString());
        }
    }

    public void persist() {
        this.persist = true;
    }

    public void detach() {
        this.persist = false;
    }

    @Override
    public void setId_contact(int id_contact) {
        super.setId_contact(id_contact);
    }

    @Override
    public void setValue(String value) {
        super.setValue(value);
        if (persist) {
            save();
        }
    }

    @Override
    public void setType(String type) {
        super.setType(type); 
        if (persist) {
            save();
        }
    }

    @Override
    public void setId(int id) {
        //not allowed
    }

    public void save() {
        queries q;
        List<Object> params = new ArrayList<>();
        params.add(this.getType());
        params.add(this.getValue());

        if (this.id == -1) {
            q = queries.INSERT;
            params.add(this.getId_contact());
        } else {
            q = queries.UPDATE;
            params.add(this.id);
        }

        try {
            int rs = ConnectionUtil.execUpdate(con, q.getQ(), params,(q==queries.INSERT?true:false));
            if ( q == queries.INSERT) {
                this.id=rs;
            }
        } catch (SQLException ex) {
            Dialog.showError("ERROR", "Error guardando canal", ex.toString());
        }

    }

    public void remove() {
        if (this.id != -1) {
            try {
                int rs = ConnectionUtil.execUpdate(con, queries.REMOVE.getQ(), this.id,false);
            } catch (SQLException ex) {
                Dialog.showError("ERROR", "Error borrando contacto", ex.toString());
            }
        }
    }

    public static Channel instanceBuilder(ResultSet rs) {

        Channel c = new Channel();
        if (rs != null) {
            try {
                c.setId(rs.getInt("id"));
                c.setType(rs.getString("type"));
                c.setValue(rs.getString("value"));
                c.setId_contact(rs.getInt("id_contact"));
            } catch (SQLException ex) {
                Dialog.showError("Error SQL", "SQL creando contacto", ex.toString());
            }

        }
        return c;
    }

    public static List<Channel> getAll(Connection con) {
        List<Channel> result = new ArrayList<>();
        try {
            ResultSet rs = ConnectionUtil.execQuery(con, queries.ALL.getQ(), null);
            if (rs != null) {
                while (rs.next()) {
                    Channel n = ChannelDao.instanceBuilder(rs);
                    result.add(n);
                }
            }
        } catch (SQLException ex) {
            Dialog.showError("ERROR", "Error cargando el contactos", ex.toString());
        }
        return result;
    }

    public static List<Channel> getByValue(Connection con, String value) {
        List<Channel> result = new ArrayList<>();
        try {
            ResultSet rs = ConnectionUtil.execQuery(con, queries.FINDBYVALUE.getQ(), "%" +value + "%");
            if (rs != null) {
                while (rs.next()) {
                    Channel n = ChannelDao.instanceBuilder(rs);
                    result.add(n);
                }
            }
        } catch (SQLException ex) {
            Dialog.showError("ERROR", "Error cargando el canal", ex.toString());
        }
        return result;
    }

    public static List<Channel> getByContact(Connection con, int id_contact) {
        List<Channel> result = new ArrayList<>();
        try {
            ResultSet rs = ConnectionUtil.execQuery(con, queries.FINDBYCONTACT.getQ(), id_contact);
            if (rs != null) {
                while (rs.next()) {
                    Channel n = ChannelDao.instanceBuilder(rs);
                    result.add(n);
                }
            }
        } catch (SQLException ex) {
            Dialog.showError("ERROR", "Error cargando el canal", ex.toString());
        }
        return result;
    }
}
