package com.carlosserrano.proyectojavafx.model;

import java.time.LocalDate;
import java.util.List;


public class Contact {
    protected int id;
    protected String nickname;
    protected List<Channel> channels;
    protected LocalDate birthDate;

    public Contact(int id, String nickname, List<Channel> channels, LocalDate birthDate) {
        this.id = id;
        this.nickname = nickname;
        this.channels = channels;
        this.birthDate = birthDate;
    }

    public Contact() {
        this(-1,"",null,LocalDate.now());
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public List<Channel> getChannels() {
        return channels;
    }

    public void setChannels(List<Channel> channels) {
        this.channels = channels;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Contact other = (Contact) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Contact{" + "id=" + id + ", nickname=" + nickname + ", emails=" + channels + ", birthDate=" + birthDate + '}';
    }

}
