package com.carlosserrano.proyectojavafx.model;

public class Channel {
    protected int id;
    protected String type;
    protected String value;
    protected int id_contact;

    public Channel(int id, String type, String value, int id_contact) {
        this.id = id;
        this.type = type;
        this.value = value;
        this.id_contact = id_contact;
    }

    public Channel() {
        this.id=-1;
        this.type="";
        this.value="";
        this.id_contact=-1;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public int getId_contact() {
        return id_contact;
    }

    public void setId_contact(int id_contact) {
        this.id_contact = id_contact;
    }

    @Override
    public String toString() {
        return "Channel{" + "id=" + id + ", type=" + type + ", value=" + value + ", id_parent=" + id_contact + '}';
    }
    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Channel other = (Channel) obj;
        if (this.id != other.id) {
            return false;
        }
        return true;
    }
}
